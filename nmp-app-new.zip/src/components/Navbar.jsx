import { useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import AddDoctorModal from "./AddDoctorModal";
import { useAuth } from "../auth/AuthContext";

export default function Navbar() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [doctorModalOpen, setDoctorModalOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const { user, logout } = useAuth();

  const links = [
    { label: "Home", path: "/" },
    { label: "Find a Doctor", path: "/search" },
    { label: "Forum", path: "/forum" },
    { label: "Jobs", path: "/jobs" },
    { label: "Contact", path: "/contact" },
  ];

  const authActions = user ? [
    { label: "Account", onClick: () => navigate("/account") },
    { label: "Logout", onClick: () => { logout(); navigate("/"); } },
  ] : [
    { label: "Doctor Login", onClick: () => navigate("/doctor-login") },
    { label: "Doctor Signup", onClick: () => navigate("/doctor-signup") },
  ];

  return (
    <>
      <header className="bg-[#00342b] text-white sticky top-0 z-50 w-full">
        <nav className="flex justify-between items-center w-full px-4 md:px-12 py-4 max-w-[1500px] mx-auto gap-4">
          <Link to="/" className="font-bold text-lg md:text-xl leading-tight truncate max-w-[60%] sm:max-w-none">NETWORK OF MUSLIM PHYSICIANS</Link>

          <div className="hidden md:flex items-center gap-6">
            {links.map((l) => (
              <Link key={l.path} to={l.path} className={`font-medium text-base transition-colors duration-200 hover:text-[#c2cf47] ${location.pathname === l.path ? "text-[#c2cf47] border-b-2 border-[#c2cf47] pb-0.5" : "text-white/80"}`}>
                {l.label}
              </Link>
            ))}
          </div>

          <div className="hidden md:flex items-center gap-3">
            {authActions.map((a) => a.onClick ? (
              <button key={a.label} onClick={a.onClick} className="px-4 py-2 rounded-xl border border-white/15 text-sm font-semibold hover:bg-white/10 transition">{a.label}</button>
            ) : null)}
            <button onClick={() => setDoctorModalOpen(true)} className="flex items-center gap-2 bg-[#c2cf47] text-[#00342b] px-5 py-2 rounded-xl font-bold text-sm hover:bg-[#d4e053] transition shadow-md">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12 4v16m8-8H4" /></svg>
              List as a Doctor
            </button>
          </div>

          <button className="md:hidden p-2" onClick={() => setMenuOpen((o) => !o)} aria-label="Toggle menu">
            {menuOpen ? (
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
            ) : (
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" /></svg>
            )}
          </button>
        </nav>

        {menuOpen && (
          <div className="md:hidden bg-[#00342b] border-t border-white/10 flex flex-col px-4 py-2 shadow-lg">
            {links.map((l) => (
              <Link key={l.path} to={l.path} onClick={() => setMenuOpen(false)} className={`py-3 border-b border-white/10 font-medium text-base ${location.pathname === l.path ? "text-[#c2cf47]" : "text-white/80"}`}>
                {l.label}
              </Link>
            ))}
            <div className="grid grid-cols-2 gap-3 py-3">
              {user ? (
                <>
                  <button onClick={() => { setMenuOpen(false); navigate('/account'); }} className="rounded-xl border border-white/15 py-3 text-sm font-semibold">Account</button>
                  <button onClick={() => { setMenuOpen(false); logout(); navigate('/'); }} className="rounded-xl border border-white/15 py-3 text-sm font-semibold">Logout</button>
                </>
              ) : (
                <>
                  <button onClick={() => { setMenuOpen(false); navigate('/doctor-login'); }} className="rounded-xl border border-white/15 py-3 text-sm font-semibold">Login</button>
                  <button onClick={() => { setMenuOpen(false); navigate('/doctor-signup'); }} className="rounded-xl border border-white/15 py-3 text-sm font-semibold">Signup</button>
                </>
              )}
            </div>
            <button onClick={() => { setMenuOpen(false); setDoctorModalOpen(true); }} className="my-3 flex items-center justify-center gap-2 bg-[#c2cf47] text-[#00342b] px-5 py-3 rounded-xl font-bold text-sm"><svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12 4v16m8-8H4" /></svg>List as a Doctor</button>
          </div>
        )}
      </header>

      <AddDoctorModal open={doctorModalOpen} onClose={() => setDoctorModalOpen(false)} />
    </>
  );
}
