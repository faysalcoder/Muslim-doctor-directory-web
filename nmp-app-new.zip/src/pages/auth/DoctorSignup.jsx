import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import toast from "react-hot-toast";
import { registerMember } from "../../api/axios";
import { useAuth } from "../../auth/AuthContext";

export default function DoctorSignup() {
  const navigate = useNavigate();
  const { login } = useAuth();
  const [form, setForm] = useState({ name: "", email: "", phone: "", password: "" });
  const [loading, setLoading] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await registerMember(form);
      if (res?.success) {
        login(res.user, res.token);
        toast.success("Account created successfully");
        navigate("/account/profile");
      } else toast.error(res?.message || "Signup failed");
    } catch (err) {
      toast.error(err.message || "Signup failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#00342b] to-[#004d3d] flex items-center justify-center p-4">
      <div className="w-full max-w-lg bg-white rounded-3xl shadow-2xl p-8 md:p-10">
        <h1 className="text-2xl font-extrabold text-[#00342b]">Doctor Signup</h1>
        <p className="text-sm text-gray-500 mt-1 mb-8">Create your account with name, email, phone, and password.</p>
        <form onSubmit={submit} className="grid gap-4">
          <input className="w-full h-12 border rounded-xl px-4" placeholder="Full name" value={form.name} onChange={(e)=>setForm({...form,name:e.target.value})} required />
          <input className="w-full h-12 border rounded-xl px-4" type="email" placeholder="Email" value={form.email} onChange={(e)=>setForm({...form,email:e.target.value})} required />
          <input className="w-full h-12 border rounded-xl px-4" placeholder="Phone number (optional)" value={form.phone} onChange={(e)=>setForm({...form,phone:e.target.value})} />
          <input className="w-full h-12 border rounded-xl px-4" type="password" placeholder="Password" value={form.password} onChange={(e)=>setForm({...form,password:e.target.value})} required />
          <button disabled={loading} className="w-full h-12 rounded-xl bg-[#00342b] text-white font-bold">{loading ? 'Creating account...' : 'Create account'}</button>
        </form>
        <div className="mt-6 text-sm flex justify-between">
          <Link to="/doctor-login" className="text-[#00342b] font-medium">Already have an account?</Link>
          <Link to="/login" className="text-gray-500">Admin login</Link>
        </div>
      </div>
    </div>
  );
}
