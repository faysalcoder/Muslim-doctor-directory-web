import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import toast from "react-hot-toast";
import { loginMember } from "../../api/axios";
import { useAuth } from "../../auth/AuthContext";

export default function DoctorLogin() {
  const navigate = useNavigate();
  const { login } = useAuth();
  const [form, setForm] = useState({ email: "", password: "" });
  const [loading, setLoading] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await loginMember(form.email, form.password);
      if (res?.success) {
        login(res.user, res.token);
        toast.success("Welcome back!");
        navigate(res.user?.role === 'member' ? '/account' : '/admin/dashboard', { replace: true });
      } else toast.error(res?.message || "Login failed");
    } catch (err) {
      toast.error(err.message || "Login failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#00342b] to-[#004d3d] flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-white rounded-3xl shadow-2xl p-8 md:p-10">
        <h1 className="text-2xl font-extrabold text-[#00342b]">Doctor Login</h1>
        <p className="text-sm text-gray-500 mt-1 mb-8">Sign in to manage your profile, forum posts, and jobs.</p>
        <form onSubmit={submit} className="space-y-4">
          <input className="w-full h-12 border rounded-xl px-4" type="email" placeholder="Email" value={form.email} onChange={(e)=>setForm({...form,email:e.target.value})} required />
          <input className="w-full h-12 border rounded-xl px-4" type="password" placeholder="Password" value={form.password} onChange={(e)=>setForm({...form,password:e.target.value})} required />
          <button disabled={loading} className="w-full h-12 rounded-xl bg-[#00342b] text-white font-bold">{loading ? 'Signing in...' : 'Login'}</button>
        </form>
        <div className="mt-6 flex items-center justify-between text-sm">
          <Link to="/doctor-signup" className="text-[#00342b] font-medium">Create account</Link>
          <Link to="/login" className="text-gray-500">Admin login</Link>
        </div>
      </div>
    </div>
  );
}
