import React, { useEffect, useRef, useState } from "react";
import toast from "react-hot-toast";
import {
  changeMemberPassword,
  getMemberProfile,
  updateMemberProfile,
} from "../../api/axios";
import { BASE_URL } from "../../api/axios";

const ALL_SPECIALTIES = [
  "Allergy & Immunology",
  "Anesthesiology",
  "Cardiology",
  "Cardiothoracic Surgery",
  "Colorectal Surgery",
  "Critical Care Medicine",
  "Dentistry & Oral Surgery",
  "Dermatology",
  "Emergency Medicine",
  "Endocrinology",
  "Family Medicine",
  "Gastroenterology",
  "General Practice",
  "General Surgery",
  "Geriatrics",
  "Hematology",
  "Hepatology",
  "Infectious Disease",
  "Internal Medicine",
  "Nephrology",
  "Neurology",
  "Neurosurgery",
  "Obstetrics & Gynecology",
  "Oncology",
  "Ophthalmology",
  "Orthopedic Surgery",
  "Otolaryngology (ENT)",
  "Pain Management",
  "Pathology",
  "Pediatrics",
  "Physical Medicine & Rehabilitation",
  "Plastic Surgery",
  "Psychiatry",
  "Pulmonology",
  "Radiology",
  "Rheumatology",
  "Sleep Medicine",
  "Sports Medicine",
  "Urology",
  "Vascular Surgery",
];

// ── Tiny helpers ────────────────────────────────────────────────────────────
function Field({
  label,
  name,
  value,
  onChange,
  type = "text",
  hint,
  required = false,
  placeholder,
  min,
  max,
  className = "",
}) {
  return (
    <div className={`space-y-1.5 ${className}`}>
      <label className="block text-xs font-semibold uppercase tracking-wide text-gray-500">
        {label}
        {required ? <span className="text-red-500 ml-1">*</span> : null}
      </label>
      <input
        type={type}
        name={name}
        value={value || ""}
        onChange={onChange}
        placeholder={placeholder || label}
        required={required}
        min={min}
        max={max}
        className="w-full h-11 border border-gray-200 rounded-xl px-4 text-sm focus:ring-2 focus:ring-[#00342b] focus:border-[#00342b] outline-none bg-white"
      />
      {hint && <p className="text-xs text-gray-400">{hint}</p>}
    </div>
  );
}

function Textarea({
  label,
  name,
  value,
  onChange,
  rows = 4,
  placeholder,
  className = "",
}) {
  return (
    <div className={`space-y-1.5 ${className}`}>
      <label className="block text-xs font-semibold uppercase tracking-wide text-gray-500">
        {label}
      </label>
      <textarea
        name={name}
        rows={rows}
        value={value || ""}
        onChange={onChange}
        placeholder={placeholder || label}
        className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-[#00342b] focus:border-[#00342b] outline-none resize-y bg-white"
      />
    </div>
  );
}

function Select({ label, name, value, onChange, options, className = "" }) {
  return (
    <div className={`space-y-1.5 ${className}`}>
      <label className="block text-xs font-semibold uppercase tracking-wide text-gray-500">
        {label}
      </label>
      <select
        name={name}
        value={value || ""}
        onChange={onChange}
        className="w-full h-11 border border-gray-200 rounded-xl px-4 text-sm focus:ring-2 focus:ring-[#00342b] focus:border-[#00342b] outline-none bg-white"
      >
        {options.map(([val, lab]) => (
          <option key={val} value={val}>
            {lab}
          </option>
        ))}
      </select>
    </div>
  );
}

function SectionHead({ title, subtitle }) {
  return (
    <div className="pb-4 border-b border-gray-100 mb-6">
      <h2 className="text-lg font-bold text-[#00342b]">{title}</h2>
      {subtitle && <p className="text-xs text-gray-400 mt-0.5">{subtitle}</p>}
    </div>
  );
}

function StatusBadge({ status }) {
  const map = {
    verified: "bg-green-100 text-green-700",
    pending: "bg-yellow-100 text-yellow-700",
    inactive: "bg-red-100 text-red-600",
  };

  return (
    <span
      className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold ${
        map[status] || "bg-gray-100 text-gray-600"
      }`}
    >
      <span className="w-1.5 h-1.5 rounded-full bg-current" />
      {status ? status.charAt(0).toUpperCase() + status.slice(1) : "Unknown"}
    </span>
  );
}

// ── Address helpers ────────────────────────────────────────────────────────
function parseAddress(address = "") {
  if (!address || typeof address !== "string") {
    return { street: "", city: "", state: "", zip: "", county: "" };
  }

  const parts = address
    .split("|")
    .map((part) => part.trim())
    .filter(Boolean);

  return {
    street: parts[0] || "",
    city: parts[1] || "",
    state: parts[2] || "",
    zip: parts[3] || "",
    county: parts[4] || "",
  };
}

function buildAddress({ street, city, state, zip, county }) {
  return [street, city, state, zip, county].filter(Boolean).join(" | ");
}

function safeString(value) {
  if (value === null || value === undefined) return "";
  return String(value);
}

// ── Main component ──────────────────────────────────────────────────────────
export default function MemberProfile() {
  const [form, setForm] = useState({
    name: "",
    title: "",
    academic_title: "",
    academic_affiliation: "",
    medical_school_affiliation: "",
    specialty: "",
    subspecialty: "",
    graduation_degree: "",
    graduation_year: "",
    experience: "",
    gender: "",
    languages: "",
    email: "",
    phone: "",
    practice: "",
    street: "",
    city: "",
    state: "",
    zip: "",
    county: "",
    hospital_1: "",
    hospital_2: "",
    hospital_3: "",
    hospital_4: "",
    awards: "",
    bio: "",
    accepting_patients: "0",
    address: "",
  });

  const [pwd, setPwd] = useState({
    current_password: "",
    new_password: "",
    confirm_password: "",
  });

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [imageFile, setImageFile] = useState(null);
  const [imagePreview, setImagePreview] = useState(null);
  const fileRef = useRef();

  useEffect(() => {
    (async () => {
      try {
        const res = await getMemberProfile();
        const profile = res.data?.profile || {};

        const parsedAddress = parseAddress(profile.address || "");

        const hospitalParts = safeString(profile.hospital_affiliations)
          .split("|")
          .map((x) => x.trim())
          .filter(Boolean);

        setForm({
          name: profile.name || "",
          title: profile.title || "",
          academic_title: profile.academic_title || "",
          academic_affiliation: profile.academic_affiliation || "",
          medical_school_affiliation: profile.medical_school_affiliation || "",
          specialty: profile.specialty || "",
          subspecialty: profile.subspecialty || "",
          graduation_degree: profile.graduation_degree || "",
          graduation_year: profile.graduation_year || "",
          experience: profile.experience || "",
          gender: profile.gender || "",
          languages: profile.languages || "",
          email: profile.email || "",
          phone: profile.phone || "",
          practice: profile.practice || "",
          street: parsedAddress.street || "",
          city: parsedAddress.city || "",
          state: parsedAddress.state || "",
          zip: parsedAddress.zip || "",
          county: parsedAddress.county || "",
          hospital_1: hospitalParts[0] || "",
          hospital_2: hospitalParts[1] || "",
          hospital_3: hospitalParts[2] || "",
          hospital_4: hospitalParts[3] || "",
          awards: profile.awards || "",
          bio: profile.bio || "",
          accepting_patients:
            String(profile.accepting_patients) === "1" ? "1" : "0",
          address: profile.address || "",
        });

        if (profile.profile_image) {
          if (String(profile.profile_image).startsWith("http")) {
            setImagePreview(profile.profile_image);
          } else {
            setImagePreview(
              `${BASE_URL}/uploads/doctors/${profile.profile_image}`,
            );
          }
        }
      } catch (e) {
        toast.error(e.message || "Failed to load profile");
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;

    setForm((prev) => {
      const next = { ...prev, [name]: value };

      // City becomes the location source automatically
      if (name === "city") {
        next.address = buildAddress({
          street: next.street,
          city: value,
          state: next.state,
          zip: next.zip,
          county: next.county,
        });
      }

      if (
        ["street", "state", "zip", "county"].includes(name) &&
        next.city !== undefined
      ) {
        next.address = buildAddress({
          street: next.street,
          city: next.city,
          state: next.state,
          zip: next.zip,
          county: next.county,
        });
      }

      return next;
    });
  };

  const handleImageChange = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      toast.error("Image must be under 5MB");
      return;
    }

    setImageFile(file);
    setImagePreview(URL.createObjectURL(file));
  };

  const saveProfile = async (e) => {
    e.preventDefault();
    setSaving(true);

    try {
      const hospitals = [
        form.hospital_1,
        form.hospital_2,
        form.hospital_3,
        form.hospital_4,
      ]
        .map((h) => h.trim())
        .filter(Boolean)
        .join(" | ");

      const fullAddress = buildAddress({
        street: form.street,
        city: form.city,
        state: form.state,
        zip: form.zip,
        county: form.county,
      });

      const location = form.city.trim();

      const payload = {
        name: form.name,
        title: form.title,
        specialty: form.specialty,
        subspecialty: form.subspecialty,
        email: form.email,
        phone: form.phone,
        location,
        practice: form.practice,
        address: fullAddress,
        bio: form.bio,
        education: [
          form.graduation_degree && form.graduation_year
            ? `${form.graduation_degree} (${form.graduation_year})`
            : form.graduation_degree || form.graduation_year,
          form.academic_title,
          form.academic_affiliation,
          form.medical_school_affiliation,
        ]
          .filter(Boolean)
          .join("; "),
        experience: form.experience,
        gender: form.gender,
        languages: form.languages,
        accepting_patients: form.accepting_patients,
        hospital_affiliations: hospitals,
        awards: form.awards,
        academic_title: form.academic_title,
        academic_affiliation: form.academic_affiliation,
        medical_school_affiliation: form.medical_school_affiliation,
        graduation_degree: form.graduation_degree,
        graduation_year: form.graduation_year,
        street: form.street,
        city: form.city,
        state: form.state,
        zip: form.zip,
        county: form.county,
      };

      if (imageFile) {
        const fd = new FormData();
        Object.entries(payload).forEach(([k, v]) => {
          if (v !== null && v !== undefined) fd.append(k, v);
        });
        fd.append("profile_image", imageFile);
        await updateMemberProfile(fd);
      } else {
        await updateMemberProfile(payload);
      }

      toast.success("Profile saved successfully!");
      setImageFile(null);
    } catch (e) {
      toast.error(e.message || "Save failed");
    } finally {
      setSaving(false);
    }
  };

  const savePassword = async (e) => {
    e.preventDefault();

    if (pwd.new_password !== pwd.confirm_password) {
      toast.error("New passwords do not match");
      return;
    }

    if (pwd.new_password.length < 6) {
      toast.error("Password must be at least 6 characters");
      return;
    }

    try {
      await changeMemberPassword(pwd.current_password, pwd.new_password);
      toast.success("Password updated!");
      setPwd({
        current_password: "",
        new_password: "",
        confirm_password: "",
      });
    } catch (e) {
      toast.error(e.message || "Password change failed");
    }
  };

  if (loading) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center">
        <div className="text-[#00342b] font-semibold">
          Loading your profile…
        </div>
      </div>
    );
  }

  const addressPreview = buildAddress({
    street: form.street,
    city: form.city,
    state: form.state,
    zip: form.zip,
    county: form.county,
  });

  const hospitalPreview = [
    form.hospital_1,
    form.hospital_2,
    form.hospital_3,
    form.hospital_4,
  ]
    .filter(Boolean)
    .join(" | ");

  return (
    <div className="max-w-5xl mx-auto px-4 py-8 space-y-6">
      {/* ── Status banner ─────────────────────────────────────────────────── */}
      <div className="bg-white border rounded-2xl px-6 py-4 flex items-center justify-between gap-4 flex-wrap">
        <div>
          <p className="text-xs uppercase tracking-widest text-gray-400 mb-0.5">
            Your Account
          </p>
          <p className="font-extrabold text-[#00342b] text-lg">
            {form.name || "Doctor Profile"}
          </p>
          <p className="text-sm text-gray-500">{form.email}</p>
        </div>
        <div className="flex items-center gap-3 flex-wrap">
          <StatusBadge status={form.status} />
          {form.status !== "verified" && (
            <p className="text-xs text-amber-600 bg-amber-50 border border-amber-200 px-3 py-1.5 rounded-xl">
              Your profile is awaiting admin verification before appearing in
              the doctor directory.
            </p>
          )}
        </div>
      </div>

      <form onSubmit={saveProfile} className="space-y-6">
        {/* ── Profile Photo ──────────────────────────────────────────────── */}
        <div className="bg-white border rounded-2xl p-6">
          <SectionHead
            title="Profile Photo"
            subtitle="Shown on your public doctor profile and in search results."
          />
          <div className="flex items-center gap-6">
            <div
              className="w-24 h-24 rounded-2xl bg-gray-100 border-2 border-dashed border-gray-300 overflow-hidden flex items-center justify-center cursor-pointer hover:border-[#00342b] transition"
              onClick={() => fileRef.current?.click()}
            >
              {imagePreview ? (
                <img
                  src={imagePreview}
                  alt="Profile"
                  className="w-full h-full object-cover"
                />
              ) : (
                <svg
                  className="w-10 h-10 text-gray-300"
                  fill="currentColor"
                  viewBox="0 0 20 20"
                >
                  <path
                    fillRule="evenodd"
                    d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z"
                    clipRule="evenodd"
                  />
                </svg>
              )}
            </div>
            <div>
              <button
                type="button"
                onClick={() => fileRef.current?.click()}
                className="px-4 py-2 rounded-xl border border-[#00342b] text-[#00342b] text-sm font-semibold hover:bg-[#00342b] hover:text-white transition"
              >
                {imagePreview ? "Change Photo" : "Upload Photo"}
              </button>
              <p className="text-xs text-gray-400 mt-2">
                JPG, PNG or WebP · max 5 MB
              </p>
              {imageFile && (
                <p className="text-xs text-green-600 mt-1">
                  ✓ New image selected — save to apply
                </p>
              )}
            </div>
            <input
              ref={fileRef}
              type="file"
              accept="image/jpeg,image/png,image/webp"
              className="hidden"
              onChange={handleImageChange}
            />
          </div>
        </div>

        {/* ── Personal Information ──────────────────────────────────────── */}
        <div className="bg-white border rounded-2xl p-6">
          <SectionHead
            title="Personal Information"
            subtitle="Basic details and contact information."
          />
          <div className="grid sm:grid-cols-2 gap-4">
            <Field
              label="Full Name"
              name="name"
              value={form.name}
              onChange={handleChange}
              required
            />
            <Field
              label="Phone Number"
              name="phone"
              value={form.phone}
              onChange={handleChange}
              type="tel"
              required
            />
            <Field
              label="Email Address"
              name="email"
              value={form.email}
              onChange={handleChange}
              type="email"
              required
            />
            <Select
              label="Gender"
              name="gender"
              value={form.gender}
              onChange={handleChange}
              options={[
                ["", "Select gender"],
                ["Male", "Male"],
                ["Female", "Female"],
                ["Other", "Other"],
                ["Prefer not to say", "Prefer not to say"],
              ]}
            />
            <Field
              label="Languages Spoken"
              name="languages"
              value={form.languages}
              onChange={handleChange}
              hint="Comma-separated: English, Arabic, Urdu"
            />
            <Field
              label="Years of Experience"
              name="experience"
              value={form.experience}
              onChange={handleChange}
              type="number"
              min="0"
            />
          </div>
        </div>

        {/* ── Practice & Contact ────────────────────────────────────────── */}
        <div className="bg-white border rounded-2xl p-6">
          <SectionHead
            title="Practice & Contact"
            subtitle="Practice name and full address. City is used as the location."
          />
          <div className="grid sm:grid-cols-2 gap-4">
            <Field
              label="Practice Name"
              name="practice"
              value={form.practice}
              onChange={handleChange}
              required
            />
            <Field
              label="Street Address"
              name="street"
              value={form.street}
              onChange={handleChange}
              placeholder="123 Main Street, Suite 400"
            />
            <Field
              label="City"
              name="city"
              value={form.city}
              onChange={handleChange}
              placeholder="Houston"
              hint="This will be used as your location"
            />
            <Field
              label="State / Province"
              name="state"
              value={form.state}
              onChange={handleChange}
              placeholder="TX"
            />
            <Field
              label="ZIP / Postal Code"
              name="zip"
              value={form.zip}
              onChange={handleChange}
              placeholder="77001"
            />
            <Field
              label="County"
              name="county"
              value={form.county}
              onChange={handleChange}
              placeholder="Harris County"
            />
            <div className="sm:col-span-2">
              <div className="flex items-center gap-3">
                <input
                  type="checkbox"
                  id="accepting_patients"
                  checked={form.accepting_patients === "1"}
                  onChange={(e) =>
                    setForm((prev) => ({
                      ...prev,
                      accepting_patients: e.target.checked ? "1" : "0",
                    }))
                  }
                  className="w-5 h-5 accent-[#00342b]"
                />
                <label
                  htmlFor="accepting_patients"
                  className="text-sm font-semibold text-gray-700 cursor-pointer"
                >
                  I am currently accepting new patients
                </label>
              </div>
            </div>
          </div>

          {addressPreview && (
            <div className="mt-4 rounded-xl border border-emerald-100 bg-emerald-50 px-4 py-3">
              <p className="text-[11px] uppercase tracking-widest text-[#00342b]/50 font-semibold mb-0.5">
                Preview
              </p>
              <p className="text-sm text-[#00342b]">{addressPreview}</p>
            </div>
          )}
        </div>

        {/* ── Medical Credentials ────────────────────────────────────────── */}
        <div className="bg-white border rounded-2xl p-6">
          <SectionHead
            title="Medical Credentials"
            subtitle="Specialty, degree, and professional titles."
          />
          <div className="grid sm:grid-cols-2 gap-4">
            <Field
              label="Title (e.g. MD, DO)"
              name="title"
              value={form.title}
              onChange={handleChange}
              required
            />
            <Select
              label="Specialty"
              name="specialty"
              value={form.specialty}
              onChange={handleChange}
              options={[
                ["", "Select specialty"],
                ...ALL_SPECIALTIES.map((s) => [s, s]),
              ]}
            />
            <Field
              label="Subspecialty"
              name="subspecialty"
              value={form.subspecialty}
              onChange={handleChange}
              hint="e.g. Interventional Cardiology, Pediatric Neurology"
            />
            <Field
              label="Graduation Degree"
              name="graduation_degree"
              value={form.graduation_degree}
              onChange={handleChange}
              hint="e.g. MD, MBBS, DO"
            />
            <Field
              label="Graduation Year"
              name="graduation_year"
              value={form.graduation_year}
              onChange={handleChange}
              type="number"
              hint="e.g. 2005"
            />
          </div>
        </div>

        {/* ── Academic & Affiliations ────────────────────────────────────── */}
        <div className="bg-white border rounded-2xl p-6">
          <SectionHead
            title="Academic & Affiliations"
            subtitle="Academic titles, institutions, and hospital affiliations."
          />
          <div className="grid sm:grid-cols-2 gap-4">
            <Field
              label="Academic Title"
              name="academic_title"
              value={form.academic_title}
              onChange={handleChange}
              hint="e.g. Professor, Associate Professor"
            />
            <Field
              label="Academic Affiliation"
              name="academic_affiliation"
              value={form.academic_affiliation}
              onChange={handleChange}
              hint="University or research institution"
            />
            <Field
              label="Medical School Attended"
              name="medical_school_affiliation"
              value={form.medical_school_affiliation}
              onChange={handleChange}
              className="sm:col-span-2"
            />
            <Field
              label="Hospital 1"
              name="hospital_1"
              value={form.hospital_1}
              onChange={handleChange}
              hint="First hospital or medical center"
            />
            <Field
              label="Hospital 2"
              name="hospital_2"
              value={form.hospital_2}
              onChange={handleChange}
              hint="Optional"
            />
            <Field
              label="Hospital 3"
              name="hospital_3"
              value={form.hospital_3}
              onChange={handleChange}
              hint="Optional"
            />
            <Field
              label="Hospital 4"
              name="hospital_4"
              value={form.hospital_4}
              onChange={handleChange}
              hint="Optional"
            />
          </div>

          {hospitalPreview && (
            <div className="mt-4 rounded-xl border border-emerald-100 bg-emerald-50 px-4 py-3">
              <p className="text-[11px] uppercase tracking-widest text-[#00342b]/50 font-semibold mb-0.5">
                Preview
              </p>
              <p className="text-sm text-[#00342b]">{hospitalPreview}</p>
            </div>
          )}
        </div>

        {/* ── About / Long-form ─────────────────────────────────────────── */}
        <div className="bg-white border rounded-2xl p-6">
          <SectionHead
            title="About You"
            subtitle="Biography, education summary, and awards."
          />
          <div className="space-y-4">
            <Textarea
              label="Bio / About"
              name="bio"
              value={form.bio}
              onChange={handleChange}
              rows={5}
            />
            <Textarea
              label="Education Summary"
              name="education"
              value={[
                form.graduation_degree && form.graduation_year
                  ? `${form.graduation_degree} (${form.graduation_year})`
                  : form.graduation_degree || form.graduation_year,
                form.academic_title,
                form.academic_affiliation,
                form.medical_school_affiliation,
              ]
                .filter(Boolean)
                .join("; ")}
              onChange={() => {}}
              rows={3}
              placeholder="Automatically built from degree, year, title, affiliation, and medical school"
            />
            <Textarea
              label="Awards & Honours"
              name="awards"
              value={form.awards}
              onChange={handleChange}
              rows={3}
            />
          </div>
        </div>

        {/* ── Save ──────────────────────────────────────────────────────── */}
        <div className="flex items-center justify-between bg-white border rounded-2xl px-6 py-4">
          <p className="text-xs text-gray-400">
            {form.status === "verified"
              ? "Your profile is live and visible in the doctor directory."
              : "Changes are saved but your profile won't appear publicly until verified by an admin."}
          </p>
          <button
            type="submit"
            disabled={saving}
            className="px-6 py-2.5 rounded-xl bg-[#00342b] text-white font-bold text-sm hover:bg-[#00493c] transition disabled:opacity-60 flex items-center gap-2"
          >
            {saving && (
              <svg
                className="w-4 h-4 animate-spin"
                fill="none"
                viewBox="0 0 24 24"
              >
                <circle
                  className="opacity-25"
                  cx="12"
                  cy="12"
                  r="10"
                  stroke="currentColor"
                  strokeWidth="4"
                />
                <path
                  className="opacity-75"
                  fill="currentColor"
                  d="M4 12a8 8 0 018-8v8z"
                />
              </svg>
            )}
            {saving ? "Saving…" : "Save Profile"}
          </button>
        </div>
      </form>

      {/* ── Change Password ──────────────────────────────────────────────── */}
      <form
        onSubmit={savePassword}
        className="bg-white border rounded-2xl p-6 space-y-4"
      >
        <SectionHead
          title="Change Password"
          subtitle="Leave blank to keep your current password."
        />
        <div className="grid sm:grid-cols-3 gap-4">
          <div className="space-y-1.5">
            <label className="block text-xs font-semibold uppercase tracking-wide text-gray-500">
              Current Password
            </label>
            <input
              type="password"
              className="w-full h-11 border border-gray-200 rounded-xl px-4 text-sm outline-none focus:ring-2 focus:ring-[#00342b]"
              value={pwd.current_password}
              onChange={(e) =>
                setPwd({ ...pwd, current_password: e.target.value })
              }
            />
          </div>
          <div className="space-y-1.5">
            <label className="block text-xs font-semibold uppercase tracking-wide text-gray-500">
              New Password
            </label>
            <input
              type="password"
              className="w-full h-11 border border-gray-200 rounded-xl px-4 text-sm outline-none focus:ring-2 focus:ring-[#00342b]"
              value={pwd.new_password}
              onChange={(e) => setPwd({ ...pwd, new_password: e.target.value })}
            />
          </div>
          <div className="space-y-1.5">
            <label className="block text-xs font-semibold uppercase tracking-wide text-gray-500">
              Confirm New Password
            </label>
            <input
              type="password"
              className="w-full h-11 border border-gray-200 rounded-xl px-4 text-sm outline-none focus:ring-2 focus:ring-[#00342b]"
              value={pwd.confirm_password}
              onChange={(e) =>
                setPwd({ ...pwd, confirm_password: e.target.value })
              }
            />
          </div>
        </div>
        <div className="flex justify-end">
          <button
            type="submit"
            className="px-6 py-2.5 rounded-xl bg-gray-800 text-white font-bold text-sm hover:bg-gray-900 transition"
          >
            Update Password
          </button>
        </div>
      </form>

      {/* ── View Public Profile link ──────────────────────────────────────── */}
      {form.id && (
        <div className="bg-emerald-50 border border-emerald-100 rounded-2xl px-6 py-4 flex items-center justify-between gap-4 flex-wrap">
          <div>
            <p className="font-semibold text-[#00342b] text-sm">
              Your Public Profile
            </p>
            <p className="text-xs text-gray-500 mt-0.5">
              {form.status === "verified"
                ? "Your profile is live — click to preview what the public sees."
                : "Your profile will go live once an admin approves it."}
            </p>
          </div>
          <a
            href={`/doctor/${form.id}`}
            target="_blank"
            rel="noreferrer"
            className="px-5 py-2 rounded-xl border border-[#00342b] text-[#00342b] text-sm font-semibold hover:bg-[#00342b] hover:text-white transition flex items-center gap-2"
          >
            View Profile
            <svg
              className="w-4 h-4"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
              />
            </svg>
          </a>
        </div>
      )}
    </div>
  );
}
