import React, { useEffect, useState } from "react";
import toast from "react-hot-toast";
import { getAvailableDoctors, saveAvailability } from "../../api/axios";
import { useAuth } from "../../auth/AuthContext";

export default function AvailableDoctorsPage() {
  const { user } = useAuth();
  const [list, setList] = useState([]);
  const [form, setForm] = useState({ degrees: '', year_of_experience: '', specialty: '', subspecialty: '', location: '', summary: '' });

  const load = async () => { const res = await getAvailableDoctors(); setList(res.data || []); };
  useEffect(() => { load(); }, []);

  const submit = async (e) => { e.preventDefault(); try { await saveAvailability(form); toast.success('Availability saved'); load(); } catch (err) { toast.error(err.message || 'Failed'); } };

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 space-y-6">
      {user && (
        <form onSubmit={submit} className="bg-white border rounded-3xl p-6 grid gap-4">
          <h1 className="text-2xl font-extrabold text-[#00342b]">Mark yourself available</h1>
          <div className="grid md:grid-cols-2 gap-4">
            {['degrees','year_of_experience','specialty','subspecialty','location'].map((k)=> <input key={k} className="w-full h-12 border rounded-xl px-4" placeholder={k.replace(/_/g,' ')} value={form[k]} onChange={(e)=>setForm({...form,[k]:e.target.value})} />)}
          </div>
          <textarea className="w-full min-h-40 border rounded-xl px-4 py-3" placeholder="Short summary" value={form.summary} onChange={(e)=>setForm({...form,summary:e.target.value})} />
          <button className="px-5 py-3 rounded-xl bg-[#00342b] text-white font-semibold w-fit">Save availability</button>
        </form>
      )}
      <div className="bg-white border rounded-3xl p-6">
        <h2 className="text-2xl font-extrabold text-[#00342b] mb-4">Available doctors</h2>
        <div className="grid gap-4">{list.map((d)=> <div key={d.id} className="border rounded-2xl p-4"><div className="font-semibold text-lg">{d.name}</div><div className="text-sm text-gray-500">{d.degrees || d.graduation_degree || ''}</div><div className="text-sm text-gray-500">{d.year_of_experience || d.doctor_experience || ''} experience</div><div className="text-sm text-gray-500">{d.specialty || d.doctor_specialty || ''} {d.subspecialty ? `• ${d.subspecialty}` : ''}</div><div className="text-sm text-gray-500">{d.location || ''}</div><div className="text-sm mt-2">{d.summary || ''}</div></div>)}{!list.length && <div className="text-center text-gray-500 py-8">No available doctors found.</div>}</div>
      </div>
    </div>
  );
}
