import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import toast from "react-hot-toast";
import { createJobPost } from "../../api/axios";

export default function CreateJobPost() {
  const navigate = useNavigate();
  const [form, setForm] = useState({ post_name: '', job_location: '', hospital_name: '', vacancy_available: '', description: '' });
  const submit = async (e) => { e.preventDefault(); try { const res = await createJobPost(form); toast.success('Job post created'); navigate('/jobs'); } catch (err) { toast.error(err.message || 'Failed'); } };
  return (
    <div className="max-w-3xl mx-auto px-4 py-8">
      <div className="bg-white border rounded-3xl p-6">
        <h1 className="text-2xl font-extrabold text-[#00342b] mb-5">Create Job Post</h1>
        <form onSubmit={submit} className="space-y-4">
          {['post_name','job_location','hospital_name','vacancy_available'].map((k)=> <input key={k} className="w-full h-12 border rounded-xl px-4" placeholder={k.replace(/_/g,' ')} value={form[k]} onChange={(e)=>setForm({...form,[k]:e.target.value})} required />)}
          <textarea className="w-full min-h-56 border rounded-xl px-4 py-3" placeholder="Job description" value={form.description} onChange={(e)=>setForm({...form,description:e.target.value})} required />
          <button className="px-5 py-3 rounded-xl bg-[#00342b] text-white font-semibold">Publish job</button>
        </form>
      </div>
    </div>
  );
}
