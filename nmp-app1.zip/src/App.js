import React from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import Login from "./pages/auth/Login";
import Dashboard from "./pages/admin/Dashboard";
import Doctors from "./pages/admin/Doctors";
import Settings from "./pages/admin/Settings";
import ProtectedRoute from "./auth/ProtectedRoute";
import PublicLayout from "./components/PublicLayout";
import HomePage from "./pages/HomePage";
import SearchPage from "./pages/SearchPage";
import ContactPage from "./pages/ContactPage";
import DoctorProfilePage from "./pages/DoctorProfilePage";
import ComingSoonModal from "./components/ComingSoonModal";

// ─────────────────────────────────────────────
// 0 = Coming Soon mode — public site shows popup
//     but admin routes remain open
// 1 = Live mode — full site works normally
// ─────────────────────────────────────────────
const SITE_MODE = 0;

export default function App() {
  return (
    <Routes>
      {/* Auth route always open */}
      <Route path="/login" element={<Login />} />

      {/* Admin Routes (always available, protected) */}
      <Route
        path="/admin/dashboard"
        element={
          <ProtectedRoute>
            <Dashboard />
          </ProtectedRoute>
        }
      />
      <Route
        path="/admin/doctors"
        element={
          <ProtectedRoute>
            <Doctors />
          </ProtectedRoute>
        }
      />
      <Route
        path="/admin/settings"
        element={
          <ProtectedRoute>
            <Settings />
          </ProtectedRoute>
        }
      />

      {/* Public Routes */}
      {SITE_MODE === 0 ? (
        <>
          <Route path="/" element={<ComingSoonModal />} />
          <Route path="/search" element={<ComingSoonModal />} />
          <Route path="/contact" element={<ComingSoonModal />} />
          <Route path="/doctor/:id" element={<ComingSoonModal />} />
        </>
      ) : (
        <Route element={<PublicLayout />}>
          <Route path="/" element={<HomePage />} />
          <Route path="/search" element={<SearchPage />} />
          <Route path="/contact" element={<ContactPage />} />
          <Route path="/doctor/:id" element={<DoctorProfilePage />} />
        </Route>
      )}

      {/* Fallback */}
      <Route
        path="*"
        element={
          <Navigate to={SITE_MODE === 0 ? "/admin/dashboard" : "/"} replace />
        }
      />
    </Routes>
  );
}
